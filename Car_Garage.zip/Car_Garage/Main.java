import java.util.Scanner;

// Base class Vehicle to demonstrate inheritance
class Vehicle {
    protected int id;
    protected int price;
    protected String name;
    protected String color;
    protected double mileage;
    protected double rating;
    protected boolean isElectric;
    protected int wheels;

    public Vehicle(int id, int price, String name, String color, double mileage, double rating, boolean isElectric, int wheels) {
        this.id = id;
        this.price = price;
        this.name = name;
        this.color = color;
        this.mileage = mileage;
        this.rating = rating;
        this.isElectric = isElectric;
        this.wheels = wheels;
    }

    public void display() {
        System.out.println("ID: " + id + ", Name: " + name + ", Price: " + price
                + ", Color: " + color + ", Mileage: " + mileage
                + ", Rating: " + rating + ", Electric: " + (isElectric ? "Yes" : "No")
                + ", Wheels: " + wheels);
    }

    public int getId() {
        return id;
    }

    public int getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public double getMileage() {
        return mileage;
    }

    public double getRating() {
        return rating;
    }

    public boolean isElectric() {
        return isElectric;
    }

    public int getWheels() {
        return wheels;
    }

    public void updateAttributes(String newName, int newPrice, String newColor,
                                 double newMileage, double newRating, boolean newElectric, int newWheels) {
        this.name = newName;
        this.price = newPrice;
        this.color = newColor;
        this.mileage = newMileage;
        this.rating = newRating;
        this.isElectric = newElectric;
        this.wheels = newWheels;
    }
}

// Derived class Car
class Car extends Vehicle {
    public Car(int id, int price, String name, String color, double mileage, double rating, boolean isElectric, int wheels) {
        super(id, price, name, color, mileage, rating, isElectric, wheels);
    }
}

// Node class for linked list
class Node {
    Vehicle vehicle;
    Node next;

    public Node(Vehicle vehicle) {
        this.vehicle = vehicle;
        this.next = null;
    }
}

// Linked list class implementing AutoCloseable
class Garage implements AutoCloseable {
    private Node head;

    public Garage() {
        this.head = null;
    }

    private boolean isDuplicateID(int id) {
        Node temp = head;
        while (temp != null) {
            if (temp.vehicle.getId() == id) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    public void insertVehicle(Vehicle vehicle) {
        if (isDuplicateID(vehicle.getId())) {
            System.out.println("Duplicate vehicle ID: " + vehicle.getId() + ". Vehicle not inserted.");
            return;
        }

        Node newNode = new Node(vehicle);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public void displayVehicle(int id) {
        Node temp = head;
        while (temp != null) {
            if (temp.vehicle.getId() == id) {
                temp.vehicle.display();
                return;
            }
            temp = temp.next;
        }
        System.out.println("Vehicle not found with ID: " + id);
    }

    public void removeVehicle(int id) {
        Node temp = head;
        Node prev = null;

        while (temp != null && temp.vehicle.getId() != id) {
            prev = temp;
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Vehicle not found with ID: " + id);
            return;
        }

        if (prev == null) {
            head = temp.next;
        } else {
            prev.next = temp.next;
        }

        System.out.println("Vehicle with ID " + id + " removed successfully.");
    }

    public void listVehicles() {
        Node temp = head;
        while (temp != null) {
            temp.vehicle.display();
            temp = temp.next;
        }
    }

    public void editVehicle(int id) {
        Node temp = head;
        Scanner scanner = new Scanner(System.in);

        while (temp != null) {
            if (temp.vehicle.getId() == id) {
                System.out.println("Choose The Option");
                System.out.println("1. Name");
                System.out.println("2. Price");
                System.out.println("3. Color");
                System.out.println("4. Mileage");
                System.out.println("5. Rating");
                System.out.println("6. Electric");
                System.out.println("7. Wheels");
                System.out.println("9. Update all fields");
                System.out.println("0. Exit");

                int option = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (option) {
                    case 1: {
                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine();
                        temp.vehicle.updateAttributes(newName, temp.vehicle.getPrice(), temp.vehicle.getColor(),
                                temp.vehicle.getMileage(), temp.vehicle.getRating(),
                                temp.vehicle.isElectric(), temp.vehicle.getWheels());
                        System.out.println("Name updated successfully.");
                        break;
                    }
                    case 2: {
                        System.out.print("Enter new price: ");
                        int newPrice = scanner.nextInt();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), newPrice, temp.vehicle.getColor(),
                                temp.vehicle.getMileage(), temp.vehicle.getRating(),
                                temp.vehicle.isElectric(), temp.vehicle.getWheels());
                        System.out.println("Price updated successfully.");
                        break;
                    }
                    case 3: {
                        System.out.print("Enter new color: ");
                        String newColor = scanner.nextLine();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), temp.vehicle.getPrice(), newColor,
                                temp.vehicle.getMileage(), temp.vehicle.getRating(),
                                temp.vehicle.isElectric(), temp.vehicle.getWheels());
                        System.out.println("Color updated successfully.");
                        break;
                    }
                    case 4: {
                        System.out.print("Enter new mileage: ");
                        double newMileage = scanner.nextDouble();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), temp.vehicle.getPrice(), temp.vehicle.getColor(),
                                newMileage, temp.vehicle.getRating(),
                                temp.vehicle.isElectric(), temp.vehicle.getWheels());
                        System.out.println("Mileage updated successfully.");
                        break;
                    }
                    case 5: {
                        System.out.print("Enter new rating: ");
                        double newRating = scanner.nextDouble();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), temp.vehicle.getPrice(), temp.vehicle.getColor(),
                                temp.vehicle.getMileage(), newRating,
                                temp.vehicle.isElectric(), temp.vehicle.getWheels());
                        System.out.println("Rating updated successfully.");
                        break;
                    }
                    case 6: {
                        System.out.print("Enter new electric status (true/false): ");
                        boolean newElectric = scanner.nextBoolean();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), temp.vehicle.getPrice(), temp.vehicle.getColor(),
                                temp.vehicle.getMileage(), temp.vehicle.getRating(),
                                newElectric, temp.vehicle.getWheels());
                        System.out.println("Electric updated successfully.");
                        break;
                    }
                    case 7: {
                        System.out.print("Enter new number of wheels: ");
                        int newWheels = scanner.nextInt();
                        temp.vehicle.updateAttributes(temp.vehicle.getName(), temp.vehicle.getPrice(), temp.vehicle.getColor(),
                                temp.vehicle.getMileage(), temp.vehicle.getRating(),
                                temp.vehicle.isElectric(), newWheels);
                        System.out.println("Wheels updated successfully.");
                        break;
                    }
                    case 9: {
                        System.out.println("Enter new details: ");
                        System.out.print("Name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Price: ");
                        int newPrice = scanner.nextInt();
                        System.out.print("Color: ");
                        scanner.nextLine(); // Consume newline
                        String newColor = scanner.nextLine();
                        System.out.print("Mileage: ");
                        double newMileage = scanner.nextDouble();
                        System.out.print("Rating: ");
                        double newRating = scanner.nextDouble();
                        System.out.print("Electric (true/false): ");
                        boolean newElectric = scanner.nextBoolean();
                        System.out.print("Wheels: ");
                        int newWheels = scanner.nextInt();

                        temp.vehicle.updateAttributes(newName, newPrice, newColor, newMileage, newRating, newElectric, newWheels);

                        System.out.println("All fields updated successfully.");
                        break;
                    }
                    case 0:
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
                return;
            }
            temp = temp.next;
        }
        System.out.println("Vehicle not found with ID: " + id);
    }

    @Override
    public void close() {
        cleanup();
    }

    public void cleanup() {
        while (head != null) {
            Node temp = head;
            head = head.next;
            temp.vehicle = null;
            temp = null;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        try (Garage garage = new Garage()) {
            // Sample usage
            

            garage.insertVehicle(new Car(1, 20000, "Toyota", "Red", 25.5, 4.2, false, 4));
            garage.insertVehicle(new Car(2, 25000, "Honda", "Blue", 28.3, 4.5, true, 4));
            garage.insertVehicle(new Car(3, 30000, "Ford", "Black", 22.1, 4.0, false, 2));
            garage.insertVehicle(new Car(3, 30000, "Ford", "Black", 22.1, 4.0, false, 2)); // Duplicate ID
            garage.insertVehicle(new Car(4, 35000, "BMW", "White", 20.7, 4.8, true, 4));
            garage.insertVehicle(new Car(5, 35000, "Audi", "Silver", 18.9, 4.6, true, 4));

            System.out.println("List of cars in the garage:");
            garage.listVehicles();

            System.out.println("\nDetails of car with ID 2:");
            garage.displayVehicle(2);

            System.out.println("\nRemoving car with ID 1...");
            garage.removeVehicle(1);

            System.out.println("\nList of cars after removal:");
            garage.listVehicles();

            System.out.println("\nEditing car with ID 4");
            garage.editVehicle(4);

            System.out.println("\nList of cars after update:");
            garage.listVehicles();
        }
    }
}
