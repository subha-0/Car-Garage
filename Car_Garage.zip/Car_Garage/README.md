javac *.java
java main